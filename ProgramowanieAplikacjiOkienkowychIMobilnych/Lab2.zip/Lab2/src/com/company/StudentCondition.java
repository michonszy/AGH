package com.company;

public enum StudentCondition {
    odrabiajacy,chory,nieobecny,obecny
}
