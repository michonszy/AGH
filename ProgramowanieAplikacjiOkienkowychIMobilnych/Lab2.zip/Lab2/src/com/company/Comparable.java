package com.company;

public interface Comparable {
}
